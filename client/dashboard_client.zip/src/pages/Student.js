import React from "react";
import BoxModel from "../components/utils/BoxModel";

const Student = () => {
  return <BoxModel />;
};

export default Student;
